
<?php $__env->startSection('content'); ?>
 <div class=" custom-product">
    <div class="col-sm-6">
   <table class="table table-striped">
    <tbody>
      <tr>
        <td>Price</td>
        <td>Rs.<?php echo e($total); ?>/-</td>
      </tr>
      <tr>
        <td>Tax</td>
        <td>Rs.0/-</td>
      </tr>
      <tr>
        <td>Delivery Charges</td>
        <td>Rs.100/-</td>
      </tr>
      <tr>
        <td>Total Amount</td>
        <td>Rs.<?php echo e($total+100); ?>/-</td>
      </tr>
    </tbody>
  </table>
       <form action="orderplace" method="post">
       <?php echo csrf_field(); ?>
       <div class="form-group">
          <textarea class="form-control" name="address" placeholder="Your Address" required></textarea>
       </div>
       <div class="form-group">
         <label for="">Payment Method</label>
          <p><input type="radio" value="cash on delivery" name="payment"><span>Online Payment</span></p>
          <p><input type="radio" value="cash on delivery" name="payment"><span>Cash On Delivery</span></p>
       </div>
         <button type="submit" class="btn btn-default">Order Now</button>
       </form>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Laptop Land\OneDrive\Desktop\Laravel\E_Commerce-urd\resources\views/ordernow.blade.php ENDPATH**/ ?>